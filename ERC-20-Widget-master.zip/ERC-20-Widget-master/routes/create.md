---
component: Generator
title: Create your ERC20 or BEP20 Token Widget | WatchToken
description: Create a Widget for your ERC20 or BEP20 Token. Enter your ERC20 or BEP20 Token details, create a Widget and share it with your users.
permalink: /create
canonicalUrl: https://vittominacori.github.io/watch-token/create/
meta:
    - property: twitter:title
      content: Create your ERC20 or BEP20 Token Widget | WatchToken
    - property: og:title
      content: Create your ERC20 or BEP20 Token Widget | WatchToken
    - property: twitter:description
      content: Create a Widget for your ERC20 or BEP20 Token. Enter your ERC20 or BEP20 Token details, create a Widget and share it with your users.
    - property: og:description
      content: Create a Widget for your ERC20 or BEP20 Token. Enter your ERC20 or BEP20 Token details, create a Widget and share it with your users.
    - property: og:url
      content: https://vittominacori.github.io/watch-token/create/
---
