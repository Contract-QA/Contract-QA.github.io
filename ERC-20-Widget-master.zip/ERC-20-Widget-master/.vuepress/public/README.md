# WatchToken

## DIST ONLY
This branch contains only the dist files from the [master branch](https://github.com/vittominacori/watch-token/tree/master), DO NOT make any changes directly to this branch, instead make your changes on the `master` branch and then run the deploy script.

To upload a file to this branch use the `.vuepress/public` folder on the `master` branch.
