<template>

</template>

<script>
  export default {
    name: 'Footer',
  };
</script>
