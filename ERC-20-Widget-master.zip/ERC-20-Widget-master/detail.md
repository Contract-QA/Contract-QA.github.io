---
component: Detail
title: Explore our Token | WatchToken
description: Discover more about our Token. View details, explore or add to MetaMask.
---
